import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import type { Collection } from '@/data/products';

export type ThemeCollection = Collection | null;

interface ThemeContextType {
  activeTheme: ThemeCollection;
  setTheme: (collection: ThemeCollection) => void;
  isTransitioning: boolean;
}

const ThemeContext = createContext<ThemeContextType | null>(null);

export const useTheme = () => {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error('useTheme must be used within ThemeProvider');
  return ctx;
};

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeTheme, setActiveTheme] = useState<ThemeCollection>(null);
  const [isTransitioning, setIsTransitioning] = useState(false);

  const setTheme = useCallback((collection: ThemeCollection) => {
    if (collection === activeTheme) return;
    setIsTransitioning(true);
    setTimeout(() => {
      setActiveTheme(collection);
      if (collection) {
        document.documentElement.setAttribute('data-theme', collection);
      } else {
        document.documentElement.removeAttribute('data-theme');
      }
      setTimeout(() => setIsTransitioning(false), 600);
    }, 500);
  }, [activeTheme]);

  useEffect(() => {
    if (activeTheme) {
      document.documentElement.setAttribute('data-theme', activeTheme);
    } else {
      document.documentElement.removeAttribute('data-theme');
    }
  }, []);

  return (
    <ThemeContext.Provider value={{ activeTheme, setTheme, isTransitioning }}>
      {children}
    </ThemeContext.Provider>
  );
};
