import { useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useTheme } from '@/context/ThemeContext';

// Couleur du rideau selon la gamme qu'on quitte ou vers laquelle on va
const curtainColors: Record<string, string> = {
  sacrae: '#C4956A',
  vitaea: '#FF6B35',
  umbrae: '#3D1A00',
  florae: '#D4A8D4',
  default: '#1a1a1a',
};

const ThemeTransition = () => {
  const { isTransitioning, activeTheme } = useTheme();
  const color = activeTheme ? curtainColors[activeTheme] : curtainColors.default;

  return (
    <AnimatePresence>
      {isTransitioning && (
        <>
          {/* Rideau 1 — descend depuis le haut */}
          <motion.div
            key="curtain-top"
            initial={{ scaleY: 0, originY: 0 }}
            animate={{ scaleY: 1, originY: 0 }}
            exit={{ scaleY: 0, originY: 0 }}
            transition={{
              duration: 0.5,
              ease: [0.76, 0, 0.24, 1],
            }}
            style={{
              position: 'fixed',
              inset: 0,
              zIndex: 9998,
              backgroundColor: color,
              opacity: 0.92,
              pointerEvents: 'none',
            }}
          />

          {/* Rideau 2 — monte depuis le bas, légèrement décalé */}
          <motion.div
            key="curtain-bottom"
            initial={{ scaleY: 0, originY: '100%' }}
            animate={{ scaleY: 0.4, originY: '100%' }}
            exit={{ scaleY: 0, originY: '100%' }}
            transition={{
              duration: 0.5,
              delay: 0.05,
              ease: [0.76, 0, 0.24, 1],
            }}
            style={{
              position: 'fixed',
              inset: 0,
              zIndex: 9997,
              backgroundColor: color,
              opacity: 0.4,
              pointerEvents: 'none',
              filter: 'blur(40px)',
            }}
          />
        </>
      )}
    </AnimatePresence>
  );
};

export default ThemeTransition;
